﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace HotelManagementSystem
{
    //this is a class to handle an API over the network.
    //so far, i decided to use an API that will get a list of countries and cities for the Address class.
    [Serializable]
    public static class APIManager
    {
        //static  client = new HttpClient();
    }
}
